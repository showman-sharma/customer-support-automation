import os.path
import pickle
import json
import base64
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from googleapiclient.discovery import build

# Define the scopes and redirect URI
SCOPES = ['https://www.googleapis.com/auth/gmail.readonly']
REDIRECT_URI = 'http://localhost:8080/oauth2callback'

def authenticate():
    creds = None
    # The file token.pickle stores the user's access and refresh tokens, and is
    # created automatically when the authorization flow completes for the first
    # time.
    if os.path.exists('token.pickle'):
        with open('token.pickle', 'rb') as token:
            creds = pickle.load(token)
    # If there are no (valid) credentials available, let the user log in.
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(
                'credentials.json', SCOPES, redirect_uri=REDIRECT_URI)
            creds = flow.run_local_server(port=0)
        # Save the credentials for the next run
        with open('token.pickle', 'wb') as token:
            pickle.dump(creds, token)
    return creds

def save_emails_to_json(folder_path, messages, service):
    for idx, message in enumerate(messages):
        email_data = {}
        # Get message details
        message_details = service.users().messages().get(userId='me', id=message['id']).execute()
        
        # Extract sender email
        sender = message_details['payload']['headers'][0]['value']
        email_data['sender'] = sender

        # Extract subject
        subject = ""
        for header in message_details['payload']['headers']:
            if header['name'] == 'Subject':
                subject = header['value']
                break
        email_data['subject'] = subject

        # Extract body
        if 'data' in message_details['payload']['body']:
            body = base64.urlsafe_b64decode(message_details['payload']['body']['data']).decode('utf-8')
        else:
            # If message body is in parts
            parts = message_details['payload']['parts']
            body = ''
            for part in parts:
                if part['mimeType'] == 'text/plain':
                    body += base64.urlsafe_b64decode(part['body']['data']).decode('utf-8')
        email_data['body'] = body

        # Save message data to JSON file
        filename = os.path.join(folder_path, f"email_{idx+1}.json")
        with open(filename, 'w') as file:
            json.dump(email_data, file, indent=4)

def main():
    creds = authenticate()
    service = build('gmail', 'v1', credentials=creds)
    # Call the Gmail API to retrieve unread messages
    results = service.users().messages().list(userId='me', labelIds=['INBOX'], q='is:unread').execute()
    messages = results.get('messages', [])
    if not messages:
        print('No new messages found.')
    else:
        print('New Messages:')
        # Save fetched emails to a folder in JSON format
        folder_path = "emails"
        if not os.path.exists(folder_path):
            os.makedirs(folder_path)
        save_emails_to_json(folder_path, messages, service)
        print(f"{len(messages)} new emails saved to {folder_path}")

if __name__ == '__main__':
    main()
