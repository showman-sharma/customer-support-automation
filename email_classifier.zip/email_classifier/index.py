import os.path
import pickle
import json
import base64
import sqlite3
import time
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from googleapiclient.discovery import build

SCOPES = ['https://www.googleapis.com/auth/gmail.readonly']
REDIRECT_URI = 'http://localhost:8080/oauth2callback'
DATABASE = 'emails.db'
TICKET_ID_FILE = 'ticket_id.txt'
POLL_INTERVAL = 1
def authenticate():
    creds = None
    if os.path.exists('token.pickle'):
        with open('token.pickle', 'rb') as token:
            creds = pickle.load(token)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file('credentials.json', SCOPES, redirect_uri=REDIRECT_URI)
            creds = flow.run_local_server(port=0)
        with open('token.pickle', 'wb') as token:
            pickle.dump(creds, token)
    return creds

def create_database():
    conn = sqlite3.connect(DATABASE)
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS emails
                 (id INTEGER PRIMARY KEY,
                  ticket_id INTEGER,
                  sender TEXT,
                  subject TEXT,
                  body TEXT)''')
    conn.commit()
    conn.close()

def save_email_to_db(email_data):
    conn = sqlite3.connect(DATABASE)
    c = conn.cursor()
    c.execute("INSERT INTO emails (ticket_id, sender, subject, body) VALUES (?, ?, ?, ?)",
              (email_data['ticket_id'], email_data['sender'], email_data['subject'], email_data['body']))
    conn.commit()
    conn.close()

def get_next_ticket_id():
    if os.path.exists(TICKET_ID_FILE):
        with open(TICKET_ID_FILE, 'r') as file:
            ticket_id = int(file.read().strip())
    else:
        ticket_id = 0
    ticket_id += 1
    with open(TICKET_ID_FILE, 'w') as file:
        file.write(str(ticket_id))
    return ticket_id

def save_emails_to_json_and_db(folder_path, messages, service):
    for idx, message in enumerate(messages):
        email_data = {}
        message_details = service.users().messages().get(userId='me', id=message['id']).execute()

        for header in message_details['payload']['headers']:
            if header['name'] == 'From':
                sender = header['value']
                break
        email_data['sender'] = sender

        subject = ""
        for header in message_details['payload']['headers']:
            if header['name'] == 'Subject':
                subject = header['value']
                break
        email_data['subject'] = subject

        if 'data' in message_details['payload']['body']:
            body = base64.urlsafe_b64decode(message_details['payload']['body']['data']).decode('utf-8')
        else:
            parts = message_details['payload']['parts']
            body = ''
            for part in parts:
                if part['mimeType'] == 'text/plain':
                    body += base64.urlsafe_b64decode(part['body']['data']).decode('utf-8')
                elif part['mimeType'] == 'text/html':
                    body += base64.urlsafe_b64decode(part['body']['data']).decode('utf-8')
        email_data['body'] = body

        email_data['ticket_id'] = get_next_ticket_id()

        filename = os.path.join(folder_path, f"email_{idx+1}_ticket_{email_data['ticket_id']}.json")
        with open(filename, 'w') as file:
            json.dump(email_data, file, indent=4)

        save_email_to_db(email_data)

def main():
    create_database()
    creds = authenticate()
    service = build('gmail', 'v1', credentials=creds)

    last_checked_time = int(time.time())

    while True:
        try:
            query = f'is:unread after:{last_checked_time}'
            results = service.users().messages().list(userId='me', labelIds=['INBOX'], q=query).execute()
            messages = results.get('messages', [])
            if messages:
                print('New Messages:')
                folder_path = "emails"
                if not os.path.exists(folder_path):
                    os.makedirs(folder_path)
                save_emails_to_json_and_db(folder_path, messages, service)
                print(f"{len(messages)} new emails saved to {folder_path} and database")

                # Update last_checked_time only after processing emails
                last_checked_time = int(time.time())

        except Exception as e:
            print(f"An error occurred: {e}")

        time.sleep(POLL_INTERVAL)

if __name__ == '__main__':
    main()